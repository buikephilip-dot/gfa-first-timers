const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const path = require('path');
const fs = require('fs');
const dotenv = require('dotenv');
const QRCode = require('qrcode');
const { Parser } = require('json2csv');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'change-me-to-random-string';
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const DB_PATH = path.join(__dirname, 'firstTimers.db');

app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const db = new sqlite3.Database(DB_PATH);

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function(err) {
      if (err) reject(err);
      else resolve(this);
    });
  });
}

function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, function(err, row) {
      if (err) reject(err);
      else resolve(row);
    });
  });
}

function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, function(err, rows) {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}

async function initDb() {
  await run(`
    CREATE TABLE IF NOT EXISTS first_timers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name TEXT NOT NULL,
      phone TEXT NOT NULL,
      email TEXT,
      address TEXT,
      gender TEXT,
      age_range TEXT,
      marital_status TEXT,
      occupation TEXT,
      how_you_heard TEXT NOT NULL,
      is_first_time TEXT NOT NULL,
      want_contact TEXT NOT NULL,
      contact_method TEXT,
      prayer_request TEXT,
      want_department TEXT NOT NULL,
      departments TEXT,
      service TEXT NOT NULL,
      date_of_visit TEXT NOT NULL,
      follow_up_status TEXT DEFAULT 'Pending',
      follow_up_notes TEXT DEFAULT '',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(phone, date_of_visit)
    )
  `);

  await run(`
    CREATE TABLE IF NOT EXISTS admin_users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      email TEXT,
      role TEXT DEFAULT 'admin',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
  `);

  const admin = await get(`SELECT * FROM admin_users WHERE username = 'admin'`);
  if (!admin) {
    const hash = bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'Admin@123', 10);
    await run(`INSERT INTO admin_users (username, password, email) VALUES (?, ?, ?)`, ['admin', hash, 'admin@gfa.local']);
  }
}

function sanitizeString(v) {
  if (v == null) return '';
  return String(v).trim();
}

function normalizePhone(v) {
  return sanitizeString(v).replace(/\s+/g, '');
}

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ')
    ? authHeader.slice(7)
    : (req.query.token || '');

  if (!token) return res.status(401).json({ error: 'Missing token' });

  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch (e) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

app.get('/', (req, res) => res.redirect('/form'));
app.get('/form', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'public', 'admin.html')));

app.post('/api/submit-first-timer', async (req, res) => {
  try {
    const body = req.body || {};
    const data = {
      full_name: sanitizeString(body.full_name),
      phone: normalizePhone(body.phone),
      email: sanitizeString(body.email),
      address: sanitizeString(body.address),
      gender: sanitizeString(body.gender),
      age_range: sanitizeString(body.age_range),
      marital_status: sanitizeString(body.marital_status),
      occupation: sanitizeString(body.occupation),
      how_you_heard: sanitizeString(body.how_you_heard),
      is_first_time: sanitizeString(body.is_first_time),
      want_contact: sanitizeString(body.want_contact),
      contact_method: sanitizeString(body.contact_method),
      prayer_request: sanitizeString(body.prayer_request),
      want_department: sanitizeString(body.want_department),
      departments: Array.isArray(body.departments) ? body.departments.join(', ') : sanitizeString(body.departments),
      service: sanitizeString(body.service),
      date_of_visit: sanitizeString(body.date_of_visit),
    };

    const required = ['full_name', 'phone', 'how_you_heard', 'is_first_time', 'want_contact', 'want_department', 'service', 'date_of_visit'];
    for (const field of required) {
      if (!data[field]) return res.status(400).json({ error: `${field.replace(/_/g, ' ')} is required` });
    }
    if (!/^\+?[0-9]{10,15}$/.test(data.phone)) {
      return res.status(400).json({ error: 'Invalid phone number format' });
    }
    if (data.want_contact === 'Yes' && !data.contact_method) {
      return res.status(400).json({ error: 'Preferred contact method is required' });
    }
    if (data.want_department === 'Yes' && !data.departments) {
      return res.status(400).json({ error: 'Please select at least one department' });
    }

    await run(`
      INSERT INTO first_timers (
        full_name, phone, email, address, gender, age_range, marital_status, occupation,
        how_you_heard, is_first_time, want_contact, contact_method, prayer_request,
        want_department, departments, service, date_of_visit
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      data.full_name, data.phone, data.email, data.address, data.gender, data.age_range,
      data.marital_status, data.occupation, data.how_you_heard, data.is_first_time,
      data.want_contact, data.contact_method, data.prayer_request, data.want_department,
      data.departments, data.service, data.date_of_visit
    ]);

    res.json({ success: true, message: 'Submission received' });
  } catch (e) {
    if (String(e.message).includes('UNIQUE constraint failed')) {
      return res.status(409).json({ error: 'This phone number has already been submitted for that date.' });
    }
    console.error(e);
    res.status(500).json({ error: 'Server error while submitting form' });
  }
});

app.post('/api/admin/login', async (req, res) => {
  try {
    const username = sanitizeString(req.body.username);
    const password = String(req.body.password || '');
    const user = await get(`SELECT * FROM admin_users WHERE username = ?`, [username]);
    if (!user) return res.status(401).json({ error: 'Invalid credentials' });

    const ok = bcrypt.compareSync(password, user.password);
    if (!ok) return res.status(401).json({ error: 'Invalid credentials' });

    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: '12h' }
    );
    res.json({ token, user: { username: user.username, role: user.role } });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Login failed' });
  }
});

app.get('/api/admin/first-timers', authMiddleware, async (req, res) => {
  try {
    const q = sanitizeString(req.query.q);
    const status = sanitizeString(req.query.status);
    const contactMethod = sanitizeString(req.query.contact_method);
    const service = sanitizeString(req.query.service);

    const where = [];
    const params = [];

    if (q) {
      where.push(`(full_name LIKE ? OR phone LIKE ?)`);
      params.push(`%${q}%`, `%${q}%`);
    }
    if (status) {
      where.push(`follow_up_status = ?`);
      params.push(status);
    }
    if (contactMethod) {
      where.push(`contact_method = ?`);
      params.push(contactMethod);
    }
    if (service) {
      where.push(`service = ?`);
      params.push(service);
    }

    const sql = `
      SELECT * FROM first_timers
      ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      ORDER BY datetime(created_at) DESC
      LIMIT 500
    `;
    const rows = await all(sql, params);
    res.json(rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Failed to fetch submissions' });
  }
});

app.get('/api/admin/first-timers/:id', authMiddleware, async (req, res) => {
  try {
    const row = await get(`SELECT * FROM first_timers WHERE id = ?`, [req.params.id]);
    if (!row) return res.status(404).json({ error: 'Submission not found' });
    res.json(row);
  } catch (e) {
    res.status(500).json({ error: 'Failed to fetch submission details' });
  }
});

app.patch('/api/admin/first-timers/:id', authMiddleware, async (req, res) => {
  try {
    const follow_up_status = sanitizeString(req.body.follow_up_status) || 'Pending';
    const follow_up_notes = sanitizeString(req.body.follow_up_notes);
    await run(`
      UPDATE first_timers
      SET follow_up_status = ?, follow_up_notes = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `, [follow_up_status, follow_up_notes, req.params.id]);
    res.json({ success: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Failed to update submission' });
  }
});

app.get('/api/admin/analytics', authMiddleware, async (req, res) => {
  try {
    const summary = await get(`
      SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN want_contact = 'Yes' THEN 1 ELSE 0 END) AS want_contact,
        SUM(CASE WHEN want_department = 'Yes' THEN 1 ELSE 0 END) AS want_department,
        SUM(CASE WHEN date(date_of_visit) >= date('now', '-6 days') THEN 1 ELSE 0 END) AS this_week
      FROM first_timers
    `);

    const byService = await all(`
      SELECT service, COUNT(*) AS count
      FROM first_timers
      GROUP BY service
      ORDER BY count DESC
    `);

    const bySource = await all(`
      SELECT how_you_heard, COUNT(*) AS count
      FROM first_timers
      GROUP BY how_you_heard
      ORDER BY count DESC
    `);

    res.json({ summary, byService, bySource });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Failed to fetch analytics' });
  }
});

app.get('/api/admin/export-csv', authMiddleware, async (req, res) => {
  try {
    const rows = await all(`SELECT * FROM first_timers ORDER BY datetime(created_at) DESC`);
    const parser = new Parser();
    const csv = parser.parse(rows);
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="gfa-first-timers.csv"');
    res.send(csv);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'CSV export failed' });
  }
});

app.get('/api/qr-code-data', async (req, res) => {
  const target = `${BASE_URL}/form`;
  const dataUrl = await QRCode.toDataURL(target, { width: 320, margin: 1 });
  res.json({ url: target, qrCodeDataUrl: dataUrl });
});

initDb().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on ${BASE_URL}`);
    console.log(`Form: ${BASE_URL}/form`);
    console.log(`Admin Dashboard: ${BASE_URL}/admin`);
  });
}).catch((e) => {
  console.error('Failed to initialize database:', e);
  process.exit(1);
});
