#!/usr/bin/env bash
set -e
echo "Installing dependencies..."
npm install
if [ ! -f .env ]; then
  cp .env.example .env
  echo ".env created from .env.example"
fi
echo "Done. Run: npm start"
